﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Board : MonoBehaviour {
    Vector3 PlayerPos;
    public Transform destination;

	// Use this for initialization
	void Start () {
        PlayerPos = transform.position;
		
	}
	
	// Update is called once per frame
	void Update () {
        if (Input.GetKeyDown(KeyCode.W))
        {
            PlayerPos += transform.forward;
            transform.position = PlayerPos;
        }
  
    
          if (Input.GetKeyDown(KeyCode.D))
            {
            PlayerPos += transform.right;
                transform.position = PlayerPos;
            }
       
         if (Input.GetKeyDown(KeyCode.A))
        {
            PlayerPos -= transform.right;
            transform.position = PlayerPos;
        }

        if (Input.GetKeyDown(KeyCode.S))
        {
            PlayerPos -= transform.forward;
            transform.position = PlayerPos;
        }

        PlayerPos.x == destination.position.x && PlayerPos.z 
        == destination.position.z){ PlayerPos += transform.up}


    }     
}
